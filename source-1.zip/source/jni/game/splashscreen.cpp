#include "../main.h"
#include "RW/RenderWare.h"
#include "game.h"
#include "gui/gui.h"

#define STB_IMAGE_IMPLEMENTATION
#include "../vendor/imgui/stb_image.h"

#include "splashscreen.png.h"

#include "audiostream.h"
extern CAudioStream *pAudioStream;

extern CGUI *pGUI;
extern CGame *pGame;

RwTexture *splashTexture = nullptr;
RwRaster *customSpashScreen = nullptr;

#define COLOR_WHITE		0xFFFFFFFF
#define COLOR_BLACK 	0xFF000000
#define COLOR_ORANGE 	0xFF00A5FF
#define COLOR_ROSE		0xFFC7FF00
#define COLOR_BRED		0xFF9933FF
#define COLOR_BLUE		0xFF6C2713
#define COLOR_CYAN		0xFFCE6816
#define COLOR_1			0xFFB58891
#define COLOR_2			0xFF673F40

struct stRect
{
	int x1;	// left
	int y1;	// top
	int x2;	// right
	int y2;	// bottom
};

struct stfRect
{
	float x1;
	float y1;
	float x2;
	float y2;
};

#define MAX_SCHEMAS 4
uint32_t colors[MAX_SCHEMAS][2] = {
	{ COLOR_ROSE,	COLOR_BRED },
	{ COLOR_BLACK, 	COLOR_ORANGE },
	{ COLOR_CYAN,	COLOR_BLUE },
	{ COLOR_1,		COLOR_2 }
};
unsigned int color_scheme = 0;

void LoadSplashTexture()
{
	Log("Loading splash texture..");
	//splashTexture = (RwTexture*)LoadTextureFromDB(BOEV("samp"), BOEV("mylogo"));
	
	int w, h;
	unsigned char *imageData = stbi_load_from_memory(splashscreen_png, splashscreen_png_len, &w, &h, NULL, 4);

	RwImage *splashImage = RwImageCreate(w, h, 4 * 8);
	RwImageAllocatePixels(splashImage);

	RwUInt8 *pixels = splashImage->cpPixels;
	for(int y = 0; y < splashImage->height; y++) {
		memcpy((unsigned char*)pixels, imageData + splashImage->stride * y, splashImage->stride);
		pixels += splashImage->stride;
	}

	RwInt32 wz, hz, d, flags;
	RwImageFindRasterFormat(splashImage, rwRASTERTYPETEXTURE, &wz, &hz, &d, &flags);
	customSpashScreen = RwRasterCreate(wz, hz, d, flags);
	customSpashScreen = RwRasterSetFromImage(customSpashScreen, splashImage);

	RwImageDestroy(splashImage);
	free(imageData);
	

	color_scheme = 1;//rand() % MAX_SCHEMAS;
}

void Draw(stRect *rect, uint32_t color, RwRaster *raster = nullptr, stfRect *uv = nullptr)
{
	static RwIm2DVertex vert[4];
	const RwReal nearScreenZ 	= *(RwReal*)(pack("0x9DAA60"));	// CSprite2d::NearScreenZ
	const RwReal recipNearClip 	= *(RwReal*)(pack("0x9DAA64"));	// CSprite2d::RecipNearClip

	RwIm2DVertexSetScreenX(&vert[0], rect->x1);
	RwIm2DVertexSetScreenY(&vert[0], rect->y2);
	RwIm2DVertexSetScreenZ(&vert[0], nearScreenZ);
	RwIm2DVertexSetRecipCameraZ(&vert[0], recipNearClip);
	vert[0].emissiveColor = color;
	RwIm2DVertexSetU(&vert[0], uv ? uv->x1 : 0.0f, recipNearClip);
	RwIm2DVertexSetV(&vert[0], uv ? uv->y2 : 0.0f, recipNearClip);

	RwIm2DVertexSetScreenX(&vert[1], rect->x2);
	RwIm2DVertexSetScreenY(&vert[1], rect->y2);
	RwIm2DVertexSetScreenZ(&vert[1], nearScreenZ);
	RwIm2DVertexSetRecipCameraZ(&vert[1], recipNearClip);
	vert[1].emissiveColor = color;
	RwIm2DVertexSetU(&vert[1], uv ? uv->x2 : 0.0f, recipNearClip);
	RwIm2DVertexSetV(&vert[1], uv ? uv->y2 : 0.0f, recipNearClip);

	RwIm2DVertexSetScreenX(&vert[2], rect->x1);
	RwIm2DVertexSetScreenY(&vert[2], rect->y1);
	RwIm2DVertexSetScreenZ(&vert[2], nearScreenZ);
	RwIm2DVertexSetRecipCameraZ(&vert[2], recipNearClip);
	vert[2].emissiveColor = color;
	RwIm2DVertexSetU(&vert[2], uv ? uv->x1 : 0.0f, recipNearClip);
	RwIm2DVertexSetV(&vert[2], uv ? uv->y1 : 0.0f, recipNearClip);

	RwIm2DVertexSetScreenX(&vert[3], rect->x2);
	RwIm2DVertexSetScreenY(&vert[3], rect->y1);
	RwIm2DVertexSetScreenZ(&vert[3], nearScreenZ);
	RwIm2DVertexSetRecipCameraZ(&vert[3], recipNearClip);
	vert[3].emissiveColor = color;
	RwIm2DVertexSetU(&vert[3], uv ? uv->x2 : 0.0f, recipNearClip);
	RwIm2DVertexSetV(&vert[3], uv ? uv->y1 : 0.0f, recipNearClip);

	RwRenderStateSet(rwRENDERSTATETEXTURERASTER, (void*)raster);
	RwIm2DRenderPrimitive(rwPRIMTYPETRISTRIP, vert, 4);
	RwRenderStateSet(rwRENDERSTATETEXTURERASTER, (void*)0);
}

void RenderSplash()
{
	stRect rect;
	stfRect uv;
	stfRect sRect;

	// background
	rect.x1 = 0;
	rect.y1 = 0;
	rect.x2 = RsGlobal->maximumWidth;
	rect.y2 = RsGlobal->maximumHeight;
	Draw(&rect, colors[color_scheme][0]);

	RwRenderStateSet(rwRENDERSTATEVERTEXALPHAENABLE, (void*)1);
	RwRenderStateSet(rwRENDERSTATETEXTUREFILTER, (void*)rwFILTERLINEAR);

	// texture
	rect.x1 = RsGlobal->maximumWidth * 0.05;
	rect.y1 = RsGlobal->maximumHeight * 0.25;
	rect.x2 = RsGlobal->maximumWidth - rect.x1;
	rect.y2 = RsGlobal->maximumHeight - rect.y1;
	uv.x1 = 0.0f;
	uv.y1 = 0.0f;
	uv.x2 = 1.0;
	uv.y2 = 1.0;
	//Draw(&rect, COLOR_WHITE, splashTexture->raster, &uv);

	float percent = *(float*)(pack("0x8F08C0"));
	if(percent <= 0.0f) return;
	float mult = percent/100.0f;
	// offset
	float newX = rect.x1 + (mult * 0.9 * RsGlobal->maximumWidth);

	sRect.x1 = (float)rect.x1; 	// x1
	sRect.y2 = (float)rect.y1; 	// y1
	sRect.x2 = (float)newX;		// x2
	sRect.y1 = (float)rect.y2;	// y2
	SetScissorRect((void*)&sRect);
	//Draw(&rect, colors[color_scheme][1], splashTexture->raster, &uv);

	sRect.x1 = 0.0f;
	sRect.y1 = 0.0f;
	sRect.x2 = 0.0f;
	sRect.y2 = 0.0f;
	SetScissorRect((void*)&sRect);
}

void ImGui_ImplRenderWare_RenderDrawData(ImDrawData* draw_data);
void ImGui_ImplRenderWare_NewFrame();

//лгбт расцветка Vadima :0
void ImDrawRectRainbow(float x, float y, float width, float height)
{
    for (float i = 0; i < width; i++)
    {
        float hue = (0.05f / width) * i;
        hue -= 0.101;
        if (hue < 0.f) hue += 1.f;

        ImColor colRainbow = ImColor::HSV(hue, 1.f, 1.f);
        ImGui::GetOverlayDrawList()->AddRectFilled(ImVec2(x + i, y), ImVec2(width, height), colRainbow);
    }
}

bool start_audio = false;
void RenderSplashScreen()
{
	RenderSplash();

	if(!pGUI) return;

	ImGuiIO& io = ImGui::GetIO();

	ImGui_ImplRenderWare_NewFrame();
	ImGui::NewFrame();

	//double scale_display = io.DisplaySize.y * 1.777777777777778;

	//ImGui::GetOverlayDrawList()->AddImage(customSpashScreen, ImVec2((io.DisplaySize.x / 2) - (io.DisplaySize.y / 7.2), io.DisplaySize.y / 7.2), ImVec2((io.DisplaySize.x / 2) + (io.DisplaySize.y / 7.2), io.DisplaySize.y / 2.4));
	
   // ImDrawRectRainbow(io.DisplaySize.x/7.11, io.DisplaySize.y/1.26, io.DisplaySize.x/1.39, io.DisplaySize.y/1.225);
   
 	if(io.DisplaySize.y <= 720)
	{
		ImGui::GetOverlayDrawList()->AddImage(customSpashScreen, ImVec2((1280/2.32) + ((io.DisplaySize.x - 1280) / 2), (720/4) + ((io.DisplaySize.y - 720) / 2)), ImVec2((1280/1.75) + ((io.DisplaySize.x - 1280) / 2), (720/2) + ((io.DisplaySize.y - 720) / 2)));
	}
	else if(io.DisplaySize.y > 720)
	{
		ImGui::GetOverlayDrawList()->AddImage(customSpashScreen, ImVec2((1920/2.32) + ((io.DisplaySize.x - 1920) / 2), (1080/4) + ((io.DisplaySize.y - 1080) / 2)), ImVec2((1920/1.75) + ((io.DisplaySize.x - 1920) / 2), (1080/2) + ((io.DisplaySize.y - 1080) / 2)));
	}
	
    ImDrawRectRainbow(io.DisplaySize.x/7.11, io.DisplaySize.y/1.26, io.DisplaySize.x/1.39, io.DisplaySize.y/1.225);
		  

	float percent = *(float*)(pack("0x8F08C0"));
	if(percent <= 0.0f) return;
	float get_length = io.DisplaySize.x - (io.DisplaySize.x/7.11);
	float get_length_percent = (get_length / 100) * percent;
	
	if(percent >= 1)
	{
		//if(!start_audio)
		//{
		//	pAudioStream->Play(BOEV("http://mordormusic.ru/music/loadingscreen.mp3"),false);
		//	start_audio = true;
		//}			
	}

	//if(percent > 95)
	//{
	//	pGame->PlayAudioStop();
	//}

	ImGui::GetOverlayDrawList()->AddRectFilled(ImVec2(get_length_percent, io.DisplaySize.y/1.26), ImVec2(io.DisplaySize.x/1.16, io.DisplaySize.y/1.225), ImColor(0,0,0));
	
	ImGui::GetOverlayDrawList()->AddText(ImVec2(0, 0), 0xffAEB259, 
		BOEV("\n\t"
		u8"Developer client: Vadima Boeva(Dalbayob)\n\t"
		u8"Client group: vk.com/canal.dalbayoba"));
		
	ImGui::GetOverlayDrawList()->AddText(ImVec2(0, pGUI->ScaleY(1010)), 0xff7D85EB, 
		BOEV("\n\t"
		u8"youtube.com/c/VadimaBoevaDalbayobTV\n\t"));			
	
	ImGui::EndFrame();
	ImGui::Render();
	ImGui_ImplRenderWare_RenderDrawData(ImGui::GetDrawData());
}
#include "main.h"
#include "gui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "game/RW/RenderWare.h"
#include "chatwindow.h"
#include "playertags.h"
#include "dialog.h"
#include "keyboard.h"
#include "settings.h"

#include "keyboard_history.h"

#include <vector>
#include <sstream>

#include "showmain.h"
#include "seatcar.h"

#include "util/CJavaWrapper.h"

//#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#include "../vendor/imgui/stb_image.h"

extern CChatWindow *pChatWindow;
extern CPlayerTags *pPlayerTags;
extern CDialogWindow *pDialogWindow;
extern CSettings *pSettings;
extern CKeyBoard *pKeyBoard;
extern CNetGame *pNetGame;

extern CShowMain *pShowMain;
extern CSeatCar *pSeatCar;

extern CKeyboardHistory *pKeyboardHistory;

/* imgui_impl_renderware.h */
void ImGui_ImplRenderWare_RenderDrawData(ImDrawData* draw_data);
bool ImGui_ImplRenderWare_Init();
void ImGui_ImplRenderWare_NewFrame();
void ImGui_ImplRenderWare_ShutDown();

/*
	Все координаты GUI-элементов задаются
	относительно разрешения 1920x1080
*/
#define MULT_X	0.00052083333f	// 1/1920
#define MULT_Y	0.00092592592f 	// 1/1080

CGUI::CGUI()
{
	Log("Initializing GUI..");

	// setup ImGUI
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO &io = ImGui::GetIO();

	ImGui_ImplRenderWare_Init();
	
	//test
	StartTest = false;

	// scale
	m_vecScale.x = io.DisplaySize.x * MULT_X;
	m_vecScale.y = io.DisplaySize.y * MULT_Y;
	// font Size
	m_fFontSize = ScaleY( pSettings->Get().fFontSize );

	// mouse/touch
	m_bMousePressed = false;
	m_vecMousePos = ImVec2(0, 0);

	Log("GUI | Scale factor: %f, %f Font size: %f", m_vecScale.x, m_vecScale.y, m_fFontSize);

	// setup style
	ImGuiStyle& style = ImGui::GetStyle();
	style.ScrollbarSize = ScaleY(55.0f);
	style.WindowBorderSize = 0.0f;
	ImGui::StyleColorsDark();


	// load fonts
	char path[0xFF];
	sprintf(path, BOEV("%sSAMP/fonts/%s"), g_pszStorage, pSettings->Get().szFont);
	// cp1251 ranges
	static const ImWchar ranges[] = 
	{
		0x0020, 0x0080,
		0x00A0, 0x00C0,
		0x0400, 0x0460,
		0x0490, 0x04A0,
		0x2010, 0x2040,
		0x20A0, 0x20B0,
		0x2110, 0x2130,
		0
	};
	Log("GUI | Loading font: %s", pSettings->Get().szFont);
	m_pFont = io.Fonts->AddFontFromFileTTF(path, m_fFontSize, nullptr, ranges);
	Log("GUI | ImFont pointer = 0x%X", m_pFont);
	
	//sprintf(path, "%sSAMP/fonts/sampaux3.ttf", g_pszStorage);
	//m_sampaux = io.Fonts->AddFontFromFileTTF(path, m_fFontSize, nullptr, ranges);
}

CGUI::~CGUI()
{
	ImGui_ImplRenderWare_ShutDown();
	ImGui::DestroyContext();
}

void CGUI::Render()
{
	ImGuiIO& io = ImGui::GetIO();

	ImGui_ImplRenderWare_NewFrame();
	ImGui::NewFrame();
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("x %f y %f", io.DisplaySize.x, io.DisplaySize.y);
	
	//ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2(252.546875, 400), ImVec2(350, 420), ImColor(224, 202, 22, 255));
	//ImGui::GetForegroundDrawList()->AddRect(const ImVec2& p_min, const ImVec2& p_max, ImU32 col, float rounding, ImDrawFlags flags, float thickness)

	//RenderVersion();
	
	//TestDialog();
	//RenderRakNetStatistics();
	
	if (pKeyBoard)
	{
		pKeyBoard->ProcessInputCommands();
	}	
	
	if(pPlayerTags) pPlayerTags->Render();
	
	if(pNetGame && pNetGame->GetTextDrawPool())
	{
		pNetGame->GetTextDrawPool()->Draw();
	}
	
	if(pNetGame && pNetGame->GetLabelPool())
	{
		pNetGame->GetLabelPool()->Draw();
	}
	
	//if(pChatWindow) pChatWindow->Render();

	if(pDialogWindow) pDialogWindow->Render();

	if(pKeyBoard) pKeyBoard->Render();
	if(pKeyboardHistory) 
	{
		if(!pDialogWindow->IsDialogOpen() || (pDialogWindow->IsDialogOpen() && pDialogWindow->m_byteDialogStyle != 3))
		{
			pKeyboardHistory->Render();
		}		
	}
	
	if(pShowMain) pShowMain->Render();
	
	if(pSeatCar) pSeatCar->Render();

	ImGui::EndFrame();
	ImGui::Render();
	ImGui_ImplRenderWare_RenderDrawData(ImGui::GetDrawData());

	if(m_bNeedClearMousePos)
	{
		io.MousePos = ImVec2(-1, -1);
		m_bNeedClearMousePos = false;
	}
}

bool CGUI::OnTouchEvent(int type, bool multi, int x, int y)
{
	ImGuiIO& io = ImGui::GetIO();

	if(pNetGame)
		pNetGame->GetTextDrawPool()->OnTouchEvent(type, multi, x, y);
	
	if(!pKeyBoard->OnTouchEvent(type, multi, x, y)) return false;
	
	//if dialog open - not touch chat
	if(!pDialogWindow->IsDialogOpen())
	{
		if(!pChatWindow->OnTouchEvent(type, multi, x, y)) return false;
	}

	switch(type)
	{
		case TOUCH_PUSH:
		{
			io.MousePos = ImVec2(x, y);
			io.MouseDown[0] = true;
		}
		break;

		case TOUCH_POP:
		{
			io.MouseDown[0] = false;
			m_bNeedClearMousePos = true;
		}
		break;

		case TOUCH_MOVE:
		io.MousePos = ImVec2(x, y);
		break;
	}
	
	if(pKeyboardHistory)
	{
		if(pKeyboardHistory->m_bEnabled)
		{
			if((x > io.DisplaySize.x/1.085 && x < io.DisplaySize.x/1.02) && (y > io.DisplaySize.y/4.96 && y < io.DisplaySize.y/2.32))
			{
				return false;
			}
		}
	}		

	return true;
}

void CGUI::RenderVersion()
{
	//ImGui::GetOverlayDrawList()->AddText(
	//	ImVec2(ScaleX(10), ScaleY(10)), 
	//	ImColor(IM_COL32_BLACK), "Hello World");
}

void CGUI::RenderRakNetStatistics()
{
		//StatisticsToString(rss, message, 0);

		/*ImGui::GetOverlayDrawList()->AddText(
			ImVec2(ScaleX(10), ScaleY(400)),
			ImColor(IM_COL32_BLACK), message);*/
}

void CGUI::RenderText(ImVec2& posCur, ImU32 col, bool bOutline, const char* text_begin, const char* text_end)
{
	int iOffset = pSettings->Get().iFontOutline;

	if(bOutline)
	{
		posCur.x -= iOffset;
		ImGui::GetOverlayDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.x += iOffset;
		// right 
		posCur.x += iOffset;
		ImGui::GetOverlayDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.x -= iOffset;
		// above
		posCur.y -= iOffset;
		ImGui::GetOverlayDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.y += iOffset;
		// below
		posCur.y += iOffset;
		ImGui::GetOverlayDrawList()->AddText(posCur, ImColor(IM_COL32_BLACK), text_begin, text_end);
		posCur.y -= iOffset;
	}

	ImGui::GetOverlayDrawList()->AddText(posCur, col, text_begin, text_end);
}


void CGUI::TestDialog()
{
	if(!StartTest) return;
	/*
	ImGuiIO& io = ImGui::GetIO();
	
    char displaysize_get[256];
    sprintf(displaysize_get, "%f | %f", io.DisplaySize.x, io.DisplaySize.y);

    ImGui::GetOverlayDrawList()->AddText(ImVec2(100, 100),ImColor(IM_COL32_BLACK), displaysize_get);
	*/
}